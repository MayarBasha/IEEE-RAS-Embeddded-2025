#include "mathematical.h"
int add(int a,int  b){
return a+b;
}

int sub(int a,int b){
return a-b;
}

int mul(int a,int b){

return a*b;
}

int divid(int a,int b){
if (b!=0){
    return a/b;
}

else{
     printf("error division by zero\n");
    }

}
int exp(int a,int b){
    int sum=1;
for(int i =0;i<b;i++){
    sum *=a;
}
return sum;
}


