
#ifndef mathematical_H
#define mathematical_H

int add(int a,int b);
int sub(int a,int b);
int mul(int a,int b);

int divid(int a,int b);
int exp(int a,int b);

#endif
