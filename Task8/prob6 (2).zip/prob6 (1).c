#include <stdio.h>
#include <stdlib.h>
#include "mathematical.h"
int main()
{
int a =4;
int b =0;
printf("the addition = %d\n",add(a,b));
printf("the subtraction = %d\n",sub(a,b));
printf("the multiplication  = %d\n",mul(a,b));
printf("the devision = %d\n",divid(a,b));
printf("the exponentiation = %d\n",exp(a,b));
    return 0;
}
